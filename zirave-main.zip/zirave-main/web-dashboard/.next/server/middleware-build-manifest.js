globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/330ed_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_cc54cf48._.js",
    "static/chunks/330ed_next_dist_compiled_react-dom_5181e1ff._.js",
    "static/chunks/330ed_next_dist_compiled_next-devtools_index_c0c5c4ba.js",
    "static/chunks/330ed_next_dist_compiled_f4c77bd6._.js",
    "static/chunks/330ed_next_dist_client_30506b0b._.js",
    "static/chunks/330ed_next_dist_a90ac822._.js",
    "static/chunks/330ed_@swc_helpers_cjs_df901c17._.js",
    "static/chunks/web-dashboard_a0ff3932._.js",
    "static/chunks/turbopack-web-dashboard_bdcfc262._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];