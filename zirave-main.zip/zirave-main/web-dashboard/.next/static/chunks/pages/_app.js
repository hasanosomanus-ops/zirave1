__turbopack_load_page_chunks__("/_app", [
  "static/chunks/330ed_next_dist_compiled_next-devtools_index_b30cbe2a.js",
  "static/chunks/330ed_next_dist_compiled_7d7cb352._.js",
  "static/chunks/330ed_next_dist_shared_lib_7fed5917._.js",
  "static/chunks/330ed_next_dist_client_19fc4252._.js",
  "static/chunks/330ed_next_dist_5154e40d._.js",
  "static/chunks/330ed_next_app_04634cd9.js",
  "static/chunks/[next]_entry_page-loader_ts_6d492563._.js",
  "static/chunks/330ed_react-dom_a81d79f2._.js",
  "static/chunks/330ed_fe760ac8._.js",
  "static/chunks/[root-of-the-server]__d49cc3c8._.js",
  "static/chunks/web-dashboard_pages__app_2da965e7._.js",
  "static/chunks/turbopack-web-dashboard_pages__app_f664fa9c._.js"
])
