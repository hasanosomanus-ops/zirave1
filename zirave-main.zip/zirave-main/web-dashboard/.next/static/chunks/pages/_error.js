__turbopack_load_page_chunks__("/_error", [
  "static/chunks/330ed_next_dist_compiled_next-devtools_index_b30cbe2a.js",
  "static/chunks/330ed_next_dist_compiled_7d7cb352._.js",
  "static/chunks/330ed_next_dist_shared_lib_e8d28175._.js",
  "static/chunks/330ed_next_dist_client_19fc4252._.js",
  "static/chunks/330ed_next_dist_879ef941._.js",
  "static/chunks/330ed_next_error_911e33a2.js",
  "static/chunks/[next]_entry_page-loader_ts_4a91f8f8._.js",
  "static/chunks/330ed_react-dom_a81d79f2._.js",
  "static/chunks/330ed_fe760ac8._.js",
  "static/chunks/[root-of-the-server]__553f77f2._.js",
  "static/chunks/web-dashboard_pages__error_2da965e7._.js",
  "static/chunks/turbopack-web-dashboard_pages__error_a876bafb._.js"
])
