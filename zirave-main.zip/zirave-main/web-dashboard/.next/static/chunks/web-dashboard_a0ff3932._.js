(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_cc54cf48._.js",
  "static/chunks/330ed_next_dist_compiled_react-dom_5181e1ff._.js",
  "static/chunks/330ed_next_dist_compiled_next-devtools_index_c0c5c4ba.js",
  "static/chunks/330ed_next_dist_compiled_f4c77bd6._.js",
  "static/chunks/330ed_next_dist_client_30506b0b._.js",
  "static/chunks/330ed_next_dist_a90ac822._.js",
  "static/chunks/330ed_@swc_helpers_cjs_df901c17._.js"
],
    source: "entry"
});
